/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Upload, 
  Image as ImageIcon, 
  Maximize2, 
  Download, 
  Loader2, 
  CheckCircle2, 
  AlertCircle,
  RefreshCw,
  Layout,
  Smartphone,
  Monitor,
  Square
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Global Types ---
declare global {
  interface Window {
    aistudio: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}

// --- Types ---

interface ResizedImage {
  id: string;
  url: string;
  label: string;
  aspectRatio: string;
  dimensions: string;
}

interface TargetSize {
  id: string;
  label: string;
  aspectRatio: "1:1" | "3:4" | "4:3" | "4:5" | "9:16" | "16:9" | "1:4" | "1:8" | "4:1" | "8:1" | "1.91:1";
  dimensions: string;
  category: 'Google PMax' | 'Google Display' | 'Meta Ads';
}

// --- Constants ---

const TARGET_SIZES: TargetSize[] = [
  // Google PMax
  { id: 'pmax-landscape', label: 'Landscape Feed', aspectRatio: '1.91:1', dimensions: '1200 x 628', category: 'Google PMax' },
  { id: 'pmax-square', label: 'Square Feed', aspectRatio: '1:1', dimensions: '1200 x 1200', category: 'Google PMax' },
  { id: 'pmax-portrait', label: 'Portrait (4:5)', aspectRatio: '4:5', dimensions: '960 x 1200', category: 'Google PMax' },
  
  // Google Display
  { id: 'display-h-landscape', label: 'Horizontal', aspectRatio: '16:9', dimensions: '1200 x 675', category: 'Google Display' },
  { id: 'display-leaderboard', label: 'Leaderboard', aspectRatio: '8:1', dimensions: '728 x 90', category: 'Google Display' },
  { id: 'display-skyscraper', label: 'Wide Skyscraper', aspectRatio: '1:4', dimensions: '160 x 600', category: 'Google Display' },
  { id: 'display-mrec', label: 'Medium Rectangle', aspectRatio: '4:3', dimensions: '300 x 250', category: 'Google Display' },
  
  // Meta Ads
  { id: 'meta-landscape', label: 'Landscape Feed', aspectRatio: '1.91:1', dimensions: '1200 x 628', category: 'Meta Ads' },
  { id: 'meta-video', label: 'Video Feed (16:9)', aspectRatio: '16:9', dimensions: '1920 x 1080', category: 'Meta Ads' },
  { id: 'meta-square', label: 'Square Feed', aspectRatio: '1:1', dimensions: '1080 x 1080', category: 'Meta Ads' },
  { id: 'meta-story', label: 'Stories / Reels', aspectRatio: '9:16', dimensions: '1080 x 1920', category: 'Meta Ads' },
];

interface SourceImage {
  id: string;
  url: string;
  name: string;
}

export default function App() {
  const [sourceImages, setSourceImages] = useState<SourceImage[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [results, setResults] = useState<ResizedImage[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>(['pmax-landscape', 'pmax-portrait']);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Initialize Gemini
  const [hasKey, setHasKey] = useState<boolean | null>(null);

  useEffect(() => {
    const checkKey = async () => {
      if (window.aistudio?.hasSelectedApiKey) {
        const selected = await window.aistudio.hasSelectedApiKey();
        setHasKey(selected);
      } else {
        setHasKey(true); 
      }
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    if (window.aistudio?.openSelectKey) {
      await window.aistudio.openSelectKey();
      setHasKey(true);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      Array.from(files).forEach((file: File) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setSourceImages(prev => [...prev, {
            id: Math.random().toString(36).substr(2, 9),
            url: reader.result as string,
            name: file.name
          }]);
        };
        reader.readAsDataURL(file);
      });
      setError(null);
    }
  };

  const removeSourceImage = (id: string) => {
    setSourceImages(prev => prev.filter(img => img.id !== id));
  };

  const toggleSizeSelection = (id: string) => {
    setSelectedSizes(prev => 
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    );
  };

  const [activeCategory, setActiveCategory] = useState<TargetSize['category']>('Google PMax');

  const selectAllInCategory = (category: TargetSize['category']) => {
    const categoryIds = TARGET_SIZES.filter(s => s.category === category).map(s => s.id);
    setSelectedSizes(prev => {
      const otherCategories = prev.filter(id => !categoryIds.includes(id));
      return [...otherCategories, ...categoryIds];
    });
  };

  const deselectAllInCategory = (category: TargetSize['category']) => {
    const categoryIds = TARGET_SIZES.filter(s => s.category === category).map(s => s.id);
    setSelectedSizes(prev => prev.filter(id => !categoryIds.includes(id)));
  };

  const [showSafeZones, setShowSafeZones] = useState(false);

  const resizeImage = async () => {
    if (sourceImages.length === 0 || selectedSizes.length === 0) return;

    setIsProcessing(true);
    setError(null);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

      // Process each source image
      for (const source of sourceImages) {
        const base64Data = source.url.split(',')[1];
        const mimeType = source.url.split(';')[0].split(':')[1];

        // Process each selected size in parallel for this specific image
        const resizePromises = selectedSizes.map(async (sizeId) => {
          const target = TARGET_SIZES.find(s => s.id === sizeId);
          if (!target) return null;

          try {
            const response = await ai.models.generateContent({
              model: 'gemini-3.1-flash-image-preview',
              contents: {
                parts: [
                  {
                    inlineData: {
                      data: base64Data,
                      mimeType: mimeType,
                    },
                  },
                  {
                    text: `Resize this 1:1 creative to a ${target.aspectRatio} aspect ratio for a ${target.label} ad. 
                    
                    CRITICAL DESIGN RULES FOR AD COMPLIANCE:
                    1. SAFE ZONES: Keep all text, logos, and key product elements at least 12% away from ALL edges. Do NOT place any text or important graphics near the borders.
                    2. COMPOSITION: Intelligently reposition the main elements to fit the new ${target.aspectRatio} layout naturally. 
                    3. BACKGROUND: Extend the background or adjust the composition so it looks like a professional design, not just a stretched image. Use generative fill techniques to maintain texture and lighting.
                    4. BRANDING: Maintain brand consistency and visual hierarchy. 
                    
                    The final image MUST be exactly ${target.aspectRatio} aspect ratio with clear padding around the edges.`,
                  },
                ],
              },
              config: {
                imageConfig: {
                  aspectRatio: target.aspectRatio,
                  imageSize: "1K"
                },
              },
            });

            let imageUrl = '';
            for (const part of response.candidates[0].content.parts) {
              if (part.inlineData) {
                imageUrl = `data:image/png;base64,${part.inlineData.data}`;
                break;
              }
            }

            if (imageUrl) {
              const result = {
                id: `${source.id}-${sizeId}-${Date.now()}`,
                url: imageUrl,
                label: `${target.label} (${source.name})`,
                aspectRatio: target.aspectRatio,
                dimensions: target.dimensions,
              };
              setResults(prev => [result, ...prev]);
              return result;
            }
          } catch (innerErr: any) {
            console.error(`Error resizing ${source.name} for ${sizeId}:`, innerErr);
            if (innerErr.message?.includes("Requested entity was not found")) {
              setHasKey(false);
              throw new Error("API Key session expired. Please re-select your key.");
            }
            return null;
          }
          return null;
        });

        // Wait for all sizes of the current image to finish before moving to next image
        // to avoid hitting rate limits too hard while still being fast
        await Promise.all(resizePromises);
      }
    } catch (err: any) {
      console.error("Batch resizing error:", err);
      setError(err.message || "An error occurred during resizing.");
    } finally {
      setIsProcessing(false);
    }
  };

  if (hasKey === false) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl p-8 text-center space-y-6 border border-[#141414]/5">
          <div className="w-16 h-16 bg-[#141414] rounded-2xl flex items-center justify-center mx-auto shadow-lg">
            <Maximize2 className="text-white w-8 h-8" />
          </div>
          <div className="space-y-2">
            <h1 className="text-2xl font-bold tracking-tight">API Key Required</h1>
            <p className="text-sm text-[#141414]/60 leading-relaxed">
              To use Gemini 3.1's advanced image generation and resizing capabilities, you need to select a paid API key from your Google Cloud project.
            </p>
          </div>
          <div className="pt-4 space-y-4">
            <button
              onClick={handleSelectKey}
              className="w-full py-4 bg-[#141414] text-white rounded-xl font-semibold hover:bg-[#141414]/90 transition-all active:scale-[0.98] shadow-xl"
            >
              Select API Key
            </button>
            <p className="text-[10px] text-[#141414]/40">
              Don't have a key? Check the <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="underline hover:text-[#141414]">billing documentation</a>.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (hasKey === null) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin opacity-20" />
      </div>
    );
  }

  const downloadImage = (url: string, label: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = `${label.replace(/\s+/g, '-').toLowerCase()}-resized.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-[#F5F5F0] text-[#141414] font-sans selection:bg-[#5A5A40] selection:text-white">
      {/* Header */}
      <header className="border-b border-[#141414]/10 bg-white/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-[#141414] rounded-lg flex items-center justify-center">
              <Maximize2 className="text-white w-5 h-5" />
            </div>
            <h1 className="text-lg font-semibold tracking-tight">Smart Creative Resizer</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs font-medium uppercase tracking-widest opacity-50">Powered by Gemini 3.1</span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Left Column: Controls */}
          <div className="lg:col-span-4 space-y-8">
            <section className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold uppercase tracking-widest opacity-60">1. Upload Sources</h2>
                {sourceImages.length > 0 && (
                  <button 
                    onClick={() => setSourceImages([])}
                    className="text-xs font-medium text-red-600 hover:underline flex items-center gap-1"
                  >
                    <RefreshCw className="w-3 h-3" /> Clear All
                  </button>
                )}
              </div>
              
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="relative aspect-video rounded-2xl border-2 border-dashed border-[#141414]/20 hover:border-[#141414]/40 bg-white/50 hover:bg-white transition-all duration-300 flex flex-col items-center justify-center overflow-hidden cursor-pointer"
              >
                <div className="text-center p-8">
                  <div className="w-12 h-12 bg-[#141414]/5 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Upload className="w-6 h-6 opacity-40" />
                  </div>
                  <p className="text-sm font-medium">Click to upload 1:1 creatives</p>
                  <p className="text-xs opacity-50 mt-1">Select multiple files (PNG, JPG)</p>
                </div>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileUpload} 
                  accept="image/*" 
                  multiple
                  className="hidden" 
                />
              </div>

              {/* Uploaded Images List */}
              {sourceImages.length > 0 && (
                <div className="grid grid-cols-4 gap-2 max-h-48 overflow-y-auto p-1">
                  {sourceImages.map((img) => (
                    <div key={img.id} className="relative aspect-square rounded-lg overflow-hidden border border-[#141414]/10 group">
                      <img src={img.url} alt={img.name} className="w-full h-full object-cover" />
                      <button 
                        onClick={(e) => { e.stopPropagation(); removeSourceImage(img.id); }}
                        className="absolute top-1 right-1 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <span className="text-[10px]">×</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </section>

            <section className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold uppercase tracking-widest opacity-60">2. Target Assets</h2>
                <div className="flex gap-1">
                  {(['Google PMax', 'Google Display', 'Meta Ads'] as const).map(cat => (
                    <button
                      key={cat}
                      onClick={() => setActiveCategory(cat)}
                      className={`px-2 py-1 rounded text-[10px] font-bold transition-all ${activeCategory === cat ? 'bg-[#141414] text-white' : 'bg-white text-[#141414]/40 hover:bg-[#141414]/5'}`}
                    >
                      {cat.split(' ')[1]}
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-2xl p-4 border border-[#141414]/10 space-y-4">
                <div className="flex items-center justify-between border-b border-[#141414]/5 pb-3">
                  <h3 className="text-[10px] font-bold uppercase tracking-wider opacity-60">{activeCategory}</h3>
                  <div className="flex gap-3">
                    <button onClick={() => selectAllInCategory(activeCategory)} className="text-[10px] font-bold text-blue-600 hover:underline">Select All</button>
                    <button onClick={() => deselectAllInCategory(activeCategory)} className="text-[10px] font-bold text-red-600 hover:underline">Clear</button>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-2 max-h-[300px] overflow-y-auto pr-1">
                  {TARGET_SIZES.filter(s => s.category === activeCategory).map((size) => (
                    <button
                      key={size.id}
                      onClick={() => toggleSizeSelection(size.id)}
                      className={`flex items-center justify-between p-3 rounded-xl border transition-all duration-200 text-left
                        ${selectedSizes.includes(size.id) 
                          ? 'border-[#141414] bg-[#141414] text-white shadow-lg' 
                          : 'border-[#141414]/10 bg-[#141414]/[0.02] hover:border-[#141414]/30'}
                      `}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-7 h-7 rounded flex items-center justify-center ${selectedSizes.includes(size.id) ? 'bg-white/20' : 'bg-[#141414]/5'}`}>
                          {size.category === 'Google PMax' && <Layout className="w-3.5 h-3.5" />}
                          {size.category === 'Google Display' && <Monitor className="w-3.5 h-3.5" />}
                          {size.category === 'Meta Ads' && <Smartphone className="w-3.5 h-3.5" />}
                        </div>
                        <div>
                          <p className="text-xs font-semibold">{size.label}</p>
                          <p className={`text-[9px] uppercase tracking-wider opacity-60 ${selectedSizes.includes(size.id) ? 'text-white/80' : ''}`}>
                            {size.dimensions} • {size.aspectRatio}
                          </p>
                        </div>
                      </div>
                      {selectedSizes.includes(size.id) && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex items-center justify-between px-2">
                <span className="text-[10px] font-medium opacity-50 italic">Each selection costs approx. ₹0.10</span>
                <span className="text-[10px] font-bold uppercase tracking-tighter bg-red-100 text-red-600 px-1.5 py-0.5 rounded animate-pulse">Save Cost: Selected {selectedSizes.length} variants</span>
              </div>
            </section>

            <button
              disabled={sourceImages.length === 0 || selectedSizes.length === 0 || isProcessing}
              onClick={resizeImage}
              className={`w-full py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all duration-300
                ${sourceImages.length === 0 || selectedSizes.length === 0 || isProcessing
                  ? 'bg-[#141414]/10 text-[#141414]/30 cursor-not-allowed'
                  : 'bg-[#141414] text-white hover:bg-[#141414]/90 shadow-xl active:scale-[0.98]'}
              `}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Processing {sourceImages.length * selectedSizes.length} Creatives...
                </>
              ) : (
                <>
                  <Maximize2 className="w-5 h-5" />
                  Generate {sourceImages.length > 0 ? sourceImages.length * selectedSizes.length : ''} Creatives
                </>
              )}
            </button>

            {error && (
              <div className="p-4 bg-red-50 border border-red-100 rounded-xl flex items-start gap-3 text-red-900">
                <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                <p className="text-xs leading-relaxed">{error}</p>
              </div>
            )}
          </div>

          {/* Right Column: Results */}
          <div className="lg:col-span-8 space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <h2 className="text-sm font-semibold uppercase tracking-widest opacity-60">Generated Results</h2>
                <button 
                  onClick={() => setShowSafeZones(!showSafeZones)}
                  className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider transition-all duration-300 border
                    ${showSafeZones 
                      ? 'bg-[#141414] text-white border-[#141414]' 
                      : 'bg-white text-[#141414] border-[#141414]/10 hover:border-[#141414]/30'}
                  `}
                >
                  {showSafeZones ? 'Hide Safe Zones' : 'Show Safe Zones'}
                </button>
                {results.length > 0 && (
                  <button 
                    onClick={() => setResults([])}
                    className="text-xs font-medium text-red-600 hover:underline flex items-center gap-1"
                  >
                    Clear Results
                  </button>
                )}
              </div>
              <span className="text-xs opacity-50">{results.length} versions generated</span>
            </div>

            {results.length === 0 && !isProcessing ? (
              <div className="h-[600px] rounded-3xl border-2 border-dashed border-[#141414]/10 flex flex-col items-center justify-center text-center p-12 bg-white/30">
                <div className="w-16 h-16 bg-[#141414]/5 rounded-full flex items-center justify-center mb-6">
                  <ImageIcon className="w-8 h-8 opacity-20" />
                </div>
                <h3 className="text-xl font-medium mb-2">No results yet</h3>
                <p className="text-sm opacity-50 max-w-xs">
                  Upload a 1:1 image and select target sizes to see the AI-powered resizing in action.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <AnimatePresence mode="popLayout">
                  {isProcessing && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="col-span-full h-32 rounded-2xl bg-white shadow-sm border border-[#141414]/5 flex items-center justify-center gap-4"
                    >
                      <Loader2 className="w-6 h-6 animate-spin opacity-40" />
                      <p className="text-sm font-medium opacity-60">AI is analyzing and recomposing your creative...</p>
                    </motion.div>
                  )}
                  {results.map((result) => (
                    <motion.div
                      key={result.id}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 border border-[#141414]/5"
                    >
                      <div className="relative aspect-video bg-[#F5F5F0] overflow-hidden">
                        <img 
                          src={result.url} 
                          alt={result.label} 
                          className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-700" 
                        />
                        
                        {/* Safe Zone Overlay */}
                        {showSafeZones && (
                          <div className="absolute inset-0 pointer-events-none">
                            <div className="absolute inset-[12%] border-2 border-dashed border-red-500/50 rounded-lg">
                              <span className="absolute -top-5 left-0 text-[8px] font-bold text-red-500 uppercase tracking-widest bg-white/80 px-1 rounded">Safe Zone (12% Padding)</span>
                            </div>
                          </div>
                        )}

                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                          <button 
                            onClick={() => downloadImage(result.url, result.label)}
                            className="bg-white text-[#141414] px-6 py-2.5 rounded-full font-semibold flex items-center gap-2 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300"
                          >
                            <Download className="w-4 h-4" /> Download
                          </button>
                        </div>
                      </div>
                      <div className="p-5 flex items-center justify-between border-t border-[#141414]/5">
                        <div>
                          <p className="text-sm font-bold">{result.label}</p>
                          <p className="text-[10px] uppercase tracking-widest opacity-50 mt-0.5">
                            {result.dimensions} • {result.aspectRatio}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="px-2 py-1 rounded bg-[#141414]/5 text-[10px] font-bold uppercase tracking-tighter">AI Optimized</div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-[#141414]/10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <p className="text-xs opacity-40">© 2024 Smart Creative Resizer. Professional AI Layout Engine.</p>
          <div className="flex items-center gap-8">
            <a href="#" className="text-xs font-medium opacity-40 hover:opacity-100 transition-opacity">Documentation</a>
            <a href="#" className="text-xs font-medium opacity-40 hover:opacity-100 transition-opacity">PMax Guidelines</a>
            <a href="#" className="text-xs font-medium opacity-40 hover:opacity-100 transition-opacity">API Status</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
